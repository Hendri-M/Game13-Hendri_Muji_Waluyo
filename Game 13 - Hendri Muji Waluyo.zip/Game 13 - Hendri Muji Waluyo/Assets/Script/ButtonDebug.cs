using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonDebug : MonoBehaviour
{
    public void btn_Game(){
        Debug.Log("Button New Game is Clicked");
    }
    public void btn_Settings(){
        Debug.Log("Button Settings is Clicked");
    }
    public void btn_Exit(){
        Debug.Log("Button Exit is Clicked");
    }
    public void btn_About(){
        Debug.Log("Button About is Clicked");
    }
    public void btn_Back(){
        Debug.Log("Button Back is Clicked");
    }
    
}
